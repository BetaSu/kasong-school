// 外链新开页面
document.addEventListener(
  "click",
  (e) => {
    if (e.target.nodeName !== "A") {
      return;
    }
    const href = e.target.getAttribute("href");
    if (href) {
      e.stopPropagation();
      e.preventDefault();
      window.open(href, "_blank");
    }
  },
  { capture: true }
);

// 阻止因布局变化导致的奇怪滚动事件
window.addEventListener(
  "scroll",
  function (e) {
    e.preventDefault();
    e.stopImmediatePropagation();
  },
  true
);

// 支持空格暂停视频
window.addEventListener(
  "keydown",
  function (e) {
    const el = e.target;
    const videoToggleElList = ["BODY", "VIDEO"];
    if (!videoToggleElList.includes(el.nodeName)) {
      return;
    }
    if (e.keyCode === 32) {
      const video = document.querySelector("video");
      if (video) {
        !video.paused ? video.play() : video.pause();
      }
      e.preventDefault();
      e.stopPropagation();
    }
  },
  { capture: true }
);
