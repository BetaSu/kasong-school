const observer = new MutationObserver(function (mutations) {
  mutations.forEach(function (mutation) {
    if (!mutation.addedNodes) {
      return;
    }
    for (var i = 0; i < mutation.addedNodes.length; i++) {
      if (mutation.addedNodes[i].classList.contains("element_id")) {
        // Your logic here
      }
    }
  });
});
